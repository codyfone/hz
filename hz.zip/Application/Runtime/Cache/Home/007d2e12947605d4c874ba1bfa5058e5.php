<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" >
    <title>添加案例-<?= C('SEO_TITLE'); ?></title>
    <link href="/Public/css/CSS.css" rel="stylesheet" type="text/css">
    <link href="/Public/css/user.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet"  href="/Skin/Public/Js/datepicker/skin/default/datepicker.css">
    <link rel="stylesheet" href="/Public/js/fancybox/jquery.fancybox.css"> 
    <style>#form-box input.input_public{height:24px;line-height: 24px;}</style>
    <script type="text/javascript" src="/Skin/Public/Js/datepicker/WdatePicker.js"></script>
    <script type="text/javascript" src="/Public/js/jquery.min.js"></script>
    <script type="text/javascript" src="/Public/js/formValidator.min.js"></script>
    <script type="text/javascript" src="/Public/js/formValidatorRegex.js"></script>
    <script type="text/javascript" src="/Skin/Public/Js/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" src="/Skin/Public/Js/ueditor/ueditor.all.js"></script>
    <script type="text/javascript" src="/Skin/Public/Js/ueditor/lang/zh-cn/zh-cn.js"></script>

    <script>
      $(function () {
        $.formValidator.initConfig({formID: "form1", theme: 'ArrowSolidBox', mode: 'AutoTip', onError: function (msg) {
            alert(msg)
          }, inIframe: true});
      });
    </script>
  </head>

  <body>
  <div class="hz_top">
  <div class="hz_topbox">
    <div class="hz_topl">
      <?php if (is_login()) { ?>
        <span>欢迎！</span><a class="a_tf" href="<?= U('Member/index') ?>"><?= session('user_auth')['nickname'] ?> </a> <a class="a_te" href="<?= U('Member/index') ?>">会员中心</a>
        <a href="<?= U('Member/logout') ?>">退出</a>
      <?php } else { ?>
        <a href="<?= U('Member/login') ?>">请登录</a>
        <a class="a_te" href="<?= U('Member/register') ?>">三秒免费注册会员</a>
      <?php } ?>
    </div>
    <div class="hz_topr">
      <div class="hz_top_k hz_top_00">
        <a href="">手机版</a>
      </div>
      <div class="hz_top_k hz_top_01">
        <a href="">帮助中心</a>
      </div>
      <div class="hz_top_k hz_top_02">
        <a href=""></a>
      </div>
      <div class="hz_top_k hz_top_03">
        <a href=""></a>
      </div>
      <div class="hz_top_k hz_top_04">
        <a href="">400-1234-567</a>
      </div>
    </div>
  </div>
</div>
<div class="hz_ser">
  <div class="hz_sec_logo">
    <img src="/Public/images/in_05.png">
  </div>
  <div class="hz_sec_r">
    <form>
      <select name="" id="">
        <option value="全部">全部</option>
        <option value="厂家">厂家</option>
        <option value="设计师">设计师</option>
      </select> 
      <input value="" placeholder="输入您想要查询的内容..." class="input02">
      <input type="submit" value="" class="input01">
    </form>
  </div>
</div>
<div class="zh_nav">
  <div class="Menu">
    <div class="all">
      <div class="m_logo">
        <img src="/Public/images/logo_m.png">
      </div>
      <ul class="clearboth">
        <li class="li1"><a href="/"><span></span><em>首页</em></a></li>
        <li class="li2 li ot"><a href="<?php echo U('Zhanzhuang/index');?>"><span></span><em>展装商城</em></a></li>
        <li class="li6 li ot"><a href="<?php echo U('Index/youshi');?>"><span></span><em>汇展优势</em></a></li>
        <li class="li7 li ot"><a href="<?php echo U('Gongchang/index');?>"><span></span><em>工厂之家</em></a></li>
        <li class="li3 li ot"><a href="<?php echo U('Sheji/index');?>"><span></span><em>设计之家</em></a></li>
        <li class="li4 li ot"><a href="<?php echo U('Zhanhui/index');?>"><span></span><em>行业展会</em></a></li>
        <li class="li5 li" style="background: none;"><a href="<?php echo U('Zhanguan/index');?>"><span></span><em>展馆信息</em></a></li>
      </ul>
    </div>
  </div>
</div>

  <div id="neiye_main" class="clearfix">
    <div class="member_main">
      <div class="member_left fl">
        <div class="member_left_title"><span>个人主页</span></div>
        <div class="member_list">
  <div class="member_list_title"><span>订单中心</span></div>
  <ul>
    <li><a href=>我的方案</a></li>
     <li><a href=>最新订单</a></li>
  </ul>
</div>
<div class="member_list">
  <div class="member_list_title"><span>案例管理</span></div>
  <ul>
    <li><a href="<?php echo U('Factory/product',['act'=>add]);?>">发布案例</a></li>
    <li><a href="<?php echo U('Factory/productList',['type'=>1]);?>">我的案例</a></li>
    <li><a href="<?php echo U('Factory/productList',['type'=>2]);?>">商品案例</a></li>
  </ul>
</div>
<div class="member_list">
  <div class="member_list_title"><span>账户中心</span></div>
  <ul>
    <li><a href="<?php echo U('factory/baseinfo');?>">基本信息</a></li>
    <li><a href="<?php echo U('factory/profile');?>">资料设置</a></li>
    <li><a href="<?php echo U('factory/finnance');?>">财务管理</a></li>
  </ul>
</div>
      </div>
      <div class="member_right fr">
        <div class="m_head">
          <h3>案例详情</h3>
        </div>
        <div class="m_body">
          <form id="form1" method="post" action="">
            <table class="m_table_no_border">
              <tbody>
                <tr><th align="left">案例名称：</th><td><input class="input_public" name="title" type="text" value="<?= $info['title'] ?>" size="50" ></td></tr>
                <tr><th align="left">行业分类：</th>
                  <td>
                    <select name="industry_id" id="industry_id<?php echo ($uniqid); ?>" class="input_public" style="width:150px;">
                      <option class="">-- 请选择类别 --</option>
                      <?php foreach ($industrys as $v) { ?>
                        <option value="<?php echo $v['id']; ?>"<?php if($v['id'] == $info['industry_id']) echo ' selected'; ?>><?php echo $v['text']; ?></option>
                      <?php } ?>
                    </select></td>
                </tr>
                <tr>
                  <th align="left">规格：</th>
                  <td>
                    <select name="open_num" id="open_num<?php echo ($uinqid); ?>" class="input_public" style="width:100px;">
                      <?php $value = $info['open_num']; ?>
                      <option value=''>请选择</option>
                      <option value="1"<?php if ($value == 1) echo ' selected'; ?>>1面开口</option>  
                      <option value="2"<?php if ($value == 2) echo ' selected'; ?>>2面开口</option> 
                      <option value="3"<?php if ($value == 3) echo ' selected'; ?>>3面开口</option>  
                      <option value="4"<?php if ($value == 4) echo ' selected'; ?>>4面开口</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <th align="left">展台结构：</th>
                  <td>
                    <select name="stucture" id="stucture<?php echo ($uinqid); ?>" class="input_public" style="width:100px;">
                      <?php $value = $info['structure']; ?>
                      <option value=''>请选择</option>
                      <option value="1"<?php if ($value == 1) echo ' selected'; ?>>木质结构</option>  
                      <option value="2"<?php if ($value == 2) echo ' selected'; ?>>衍架结构</option> 
                      <option value="3"<?php if ($value == 3) echo ' selected'; ?>>型材结构</option>  
                      <option value="4"<?php if ($value == 4) echo ' selected'; ?>>双层结构</option>
                    </select>
                  </td>
                </tr>
                <tr><th align="left">面积：</th><td><input class="input_public" type="text" name="floor_area" value="<?= $info['floor_area'] ?>" size="5" > m<sup>2</sup></td></tr>
                <tr><th align="left">价格：</th><td><input class="input_public" type="text" name="price" value="<?= $info['price'] ?>" size="5" > 元</td></tr>
                <tr><th align="left" valign="top">图集展示：</th>
                  <td align="left">
                    <input name="drawing" id="drawing" type="hidden" value="<?php echo ($info['drawing']); ?>" />                    
                    <div class="span16">
                      <button type="button" class="upimage_btn" id="upimages" href="#" target="_blank"><i class="icons24 icons24-editing"></i><span>添加图片</span></button>
                      <div class="fileListbox">
                        <ul id="fileListWarp"></ul>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr><th align="left">是否商品：</th><td><select class="input_public" name="status" id="status<?php echo ($uinqid); ?>">
                      <?php $value = $info['status']; ?>
                      <option value='0'>下线</option>
                      <option value="1"<?php if ($value == 1) echo ' selected'; ?>>普通案例</option>  
                      <option value="2"<?php if ($value == 2) echo ' selected'; ?>>商品</option> 
                    </select></td></tr>
                <tr><th></th><td align="left"><input value="提交" class="dosubmit" type="submit"></td></tr>
              </tbody></table>
          </form>  
        </div>
      </div>
      <div class="clear"></div>
    </div>

  </div>

  <?php
 $about_us = M('Article')->where('cid=6')->find(); $service = M('Article')->where('cid=8')->select(); ?>
<div class="clear"></div>
<div class="hz_foot">
  <div class="hz_footbox">
    <div class="hz_footl">
      <div class="hz_footls">
        <span>ABOUT US</span>
        <p>关于我们</p>
      </div>
      <div class="hz_footlx">
          <p><?php echo mb_substr($about_us['content'],0,69,'utf-8') ?></p>
        <a href="<?php echo U('Article/view',array('id'=>$about_us['id']));?>"><img src="/Public/images/foot_03.jpg"></a>
      </div>
    </div>
    <div class="hz_footl">
      <div class="hz_footls">
        <span>OUR SERVICE</span>
        <p>我们的服务</p>
      </div>
      <div class="hz_footlx">
        <?php foreach ($service as $key => $value) { ?>
            <div class="hz_foot_a"><a href="<?php echo U('Article/view',array('id'=>$value['id']));?>"><?php echo ($value['title']); ?></a></div>  
        <?php  } ?>
      </div>
    </div>
    <div class="hz_footl hz_foot_te">
      <div class="hz_footls">
        <span>CONTACT US</span>
        <p>联系我们</p>
      </div>
      <div class="hz_footlx">
        <div class="hz_foot_lx">
          <p>地址:<span>郑州市艾尚酒店10楼</span></p>
          <p class="hz_pte">电话:<span>400-1234-567</span></p>
          <p class="hz_pte1">E-mail:<span>zhanhuizhijia@126.com</span></p>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="hz_bq">
  <div class="hz_bqbox">
    <p>Copyright © 2016展会之家 豫ICP备10011451号-6  </p>
    <a href="">技术支持：大华伟业</a>
  </div>
</div>
<script src="/Public/js/public.js"></script>
  <script type="text/plain" id="imageseditor"></script>
  <script type="text/javascript">
    var aImgList = [<?php echo ($info['drawing']); ?>];
    var iImgNum = aImgList.length;
    var aImgs = [];
    $(function () {
      var oHtml = "";
      for (var i = 0; i < iImgNum; i++) {
        oHtml += "<li id=\"img_" + i + "\"><img src=\"" + aImgList[i].src + "\" height=\"113\"><span class=\"removeimg\"></span><input class=\"text imgtxt\" type=\"text\" value=\"" + aImgList[i].txt + "\" /></li>";
        aImgs[i] = "{'src':'" + aImgList[i].src + "','txt':'" + aImgList[i].alt + "'}";

      }
      $(oHtml).appendTo("#fileListWarp");

      for (var i = 0; i < iImgNum; i++) {
        $("#img_" + i + " .removeimg").click(function () {
          var _pid = $(this).parent().remove().attr('id').substr(4);
          aImgs[_pid] = "";
          updateImgs();
        });
      }
    });
    //弹出图片上传的对话框
    function upImage(editor) {
      var myImage = editor.getDialog("insertimage");
      myImage.open();
    }
    //弹出文件上传的对话框
    function upFiles(editor) {
      var myFiles = editor.getDialog("attachment");
      myFiles.open();
    }
    function pushImgs(arr) {
      var oHtml = "";
      var _startIndex = iImgNum;
      for (var i = 0; i < arr.length; i++) {
        oHtml += "<li id=\"img_" + iImgNum + "\"><img src=\"" + arr[i].src + "\" height=\"113\"><span class=\"removeimg\"></span><input class=\"text imgtxt\" type=\"text\" value=\"" + arr[i].alt + "\"></li>";
        aImgs[iImgNum] = "{'src':'" + arr[i].src + "','txt':'" + arr[i].alt + "'}";
        iImgNum++;
      }
      $(oHtml).appendTo("#fileListWarp");
      updateImgs();
      for (var i = _startIndex; i < iImgNum; i++) {
        $("#img_" + i + " .removeimg").click(function () {
          var _pid = $(this).parent().remove().attr('id').substr(4);
          aImgs[_pid] = "";
          updateImgs();
        });
      }
    }

    function updateImgs() {
      var sValue = "";
      for (var i = 0; i < aImgs.length; i++) {
        if (aImgs[i] != "") {
          if (sValue == "") {
            sValue = aImgs[i];
          } else {
            sValue += ',' + aImgs[i]
          }
        }
      }
      $("#drawing").val(sValue);
      // alert($("#Product_images").val());
    }
  </script>

  <script type="text/javascript">
    /*<![CDATA[*/
    var upimgs = UE.getEditor('imageseditor', {
      serverUrl: '<?= U('Ueditor/upload') ?>'
      , isShow: false, initialFrameHeight: '0'
      , initialFrameWidth: '0'
    });
    upimgs.ready(function () {
      //弹出图片上传的对话框
      function upImage(editor) {
        var myImage = editor.getDialog("insertimage");
        myImage.open();
      }

      function pushImgs(arr) {
        var oHtml = "";
        var _startIndex = iImgNum;
        for (var i = 0; i < arr.length; i++) {
          oHtml += "<li id=\"img_" + iImgNum + "\"><img src=\"" + arr[i].src + "\" height=\"113\"><span class=\"removeimg\"></span><input class=\"text imgtxt\" type=\"text\" value=\"" + arr[i].alt + "\"></li>";
          aImgs[iImgNum] = "{'src':'" + arr[i].src + "','txt':'" + arr[i].alt + "'}";
          iImgNum++;
        }
        $(oHtml).appendTo("#fileListWarp");
        updateImgs();
        for (var i = _startIndex; i < iImgNum; i++) {
          $("#img_" + i + " .removeimg").click(function () {
            var _pid = $(this).parent().remove().attr('id').substr(4);
            aImgs[_pid] = "";
            updateImgs();
          });
        }
      }

      upimgs.addListener("beforeInsertImage", function (t, arg) {
        pushImgs(arg);
      });

      $("#upimages").click(function () {
        upImage(upimgs);
      });
    });

    /*]]>*/
  </script>
</body>
</html>