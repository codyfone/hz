<?php if (!defined('THINK_PATH')) exit();?><script language="javascript">
$(function(){
	var th = $(".top").height();
	th = 111-th
	var wh = $(window).height()-th;
	$("#designUserTabs").height(wh);
});
</script>
<div class="con" id="DesignIndexCon">
  <div id="designUserTabs" class="easyui-tabs">  
    <div title="待审核的方案" data-options="href:'/index.php/Admin/Design/designlist/type/0',cache:false"></div> 
    <div title="所有方案" data-options="href:'/index.php/Admin/Design/designlist/type/99',cache:false"></div> 
  </div>
  </div>