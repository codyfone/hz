<?php if (!defined('THINK_PATH')) exit();?><script language="javascript">
$(function(){
	var th = $(".top").height();
	th = 111-th;
	var wh = $(window).height()-th;
	
	$("#Exh").treegrid({
		//title:'分类列表',	
		idField:'id',
		height:wh,
		treeField:'title',
		autoRowHeight:false,
		singleSelect:true,
		striped:true,
		rownumbers:true,
		method:'get',
		url:'/index.php/Admin/Category/index/json/1',
		fitColumns:true,
		nowrap:Number('<?php echo (C("DATA_NOWRAP")); ?>'),
		onBeforeLoad: function () {  
			
		},
		onDblClickRow:function(e,rowIndex,rowData){
			var se = $(this).treegrid('getSelected');
			var idd = se['id'];
			$("#addExh").dialog({
				title:'编辑分类',
				resizable:true,
				width:805,
				height:406,
				href:'/index.php/Admin/Category/add/act/edit/id/'+idd,
				onOpen:function(){
					cancel['Exh'] = $(this);
				},
				onClose:function(){
					//$(this).dialog('destroy');
					//$("#Exh").treegrid('reload');
					cancel['Exh'] = null;
				}
			});
		},
		toolbar:[{
		iconCls: 'icon-add',
			text : '新增',
			handler: function(){
				$("#addExh").dialog({
					title:'新增分类',
					resizable:true,
                    width:805,
                    height:406,
					href:'/index.php/Admin/Category/add/act/add',
					onOpen:function(){
						cancel['Exh'] = $(this);
					},
					onClose:function(){
						//$(this).dialog('destroy');
						//$("#Exh").treegrid('reload');
						cancel['Exh'] = null;
					}
				});
			}
		},'-',{
			iconCls: 'icon-edit',
			text : '编辑',
			handler: function(){
				var se = $("#Exh").treegrid('getSelected');
				var idd = se['id'];
				$("#addExh").dialog({
					title:'编辑分类',
					resizable:true,
					width:805,
					  height:406,
					href:'/index.php/Admin/Category/add/act/edit/id/'+idd,
					onOpen:function(){
						cancel['Exh'] = $(this);
					},
					onClose:function(){
						//$(this).dialog('destroy');
						//$("#Exh").treegrid('reload');
						cancel['Exh'] = null;
					}
				});
			}
		},'-',{
			iconCls: 'icon-cancel',
			text : '删除',
			handler: function(){
				var se = $("#Exh").treegrid('getSelected');
				var idd = se['id'];
				$.messager.confirm('提示','确定刪除吗！',function(r){
					if(r==true){
						$.messager.progress();
						$.get('/index.php/Admin/Category/del/id/'+idd, function(data){
							$.messager.progress('close');
							if(data==1){
								$.messager.alert('提示','删除数据成功！','info',function(){
									$("#Exh").treegrid('reload');
								});
							}else if(data==0){
								$.messager.alert('提示','删除数据失败！','warning');
							}else{
								$.messager.alert('提示','您没有删除权限！','warning');
							}
						});
					}
				});	
			}
		},{
			iconCls: 'icon-reload',
			text : '重载',
			handler: function(){
				$("#Exh").treegrid('reload');
			}
		}
		],
		columns:[[   
			{field:'title',title:'分类标题',width:200},

		]]
	});
});
</script>
<div class="con" id="ExhCon" onselectstart="return false;" style="-moz-user-select:none;">
	<table id="Exh"></table>
</div>
<div id="addExh"></div>