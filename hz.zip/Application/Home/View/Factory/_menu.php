<div class="member_list">
  <div class="member_list_title"><span>订单中心</span></div>
  <ul>
    <li><a href=>我的方案</a></li>
     <li><a href=>最新订单</a></li>
  </ul>
</div>
<div class="member_list">
  <div class="member_list_title"><span>案例管理</span></div>
  <ul>
    <li><a href="{:U('Factory/product',['act'=>add])}">发布案例</a></li>
    <li><a href="{:U('Factory/productList',['type'=>1])}">我的案例</a></li>
    <li><a href="{:U('Factory/productList',['type'=>2])}">商品案例</a></li>
  </ul>
</div>
<div class="member_list">
  <div class="member_list_title"><span>账户中心</span></div>
  <ul>
    <li><a href="{:U('factory/baseinfo')}">基本信息</a></li>
    <li><a href="{:U('factory/profile')}">资料设置</a></li>
    <li><a href="{:U('factory/finnance')}">财务管理</a></li>
  </ul>
</div>