<?php

return array(
  'TMPL_TEMPLATE_SUFFIX' => '.php',
  'URL_MODEL' => 2,
);
