<?php

namespace Home\Controller;

/**
 * 展馆展示
 */
class ShejiController extends \Think\Controller {

  public function index() {
   
    
    
    $this->display();
  }

}
