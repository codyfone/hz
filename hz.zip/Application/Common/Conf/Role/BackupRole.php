<?php
$role = array(	
	'user'=>'a',
);