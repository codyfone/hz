<?php
$role = array(
	999=>array('r','c','u','d','p','a'),		
	'user'=>'a',
);