<?php
$role = array(
	0=>'pass',
);