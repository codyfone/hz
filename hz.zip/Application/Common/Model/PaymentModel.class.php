<?php

namespace Common\Model;

use Think\Model;

class PaymentModel extends Model {

  protected $_validate = array(
    array('pay_code', 'require', '支付方式不存在', self::MUST_VALIDATE),
    array('pay_name', 'require', '支付名称必须存在', self::MUST_VALIDATE),
    array('config', 'require', '支付配置必须存在', self::MUST_VALIDATE),
  );
  protected $_auto = array(
    array('dateline', 'time', self::MODEL_UPDATE, 'function', 1),
  );

}
