<?php
define('BIND_MODULE','Home');
define('BIND_CONTROLLER','Pay');
define('BIND_ACTION','wxpayReturn');
require dirname(dirname(__FILE__)).'/run.inc.php';
?>