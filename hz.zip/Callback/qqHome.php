<?php
define('BIND_MODULE','Home');
define('BIND_CONTROLLER','Public');
define('BIND_ACTION','qqReturn');
require dirname(dirname(__FILE__)).'/run.inc.php';
?>