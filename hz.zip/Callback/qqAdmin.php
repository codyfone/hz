<?php
define('BIND_MODULE','Admin');
define('BIND_CONTROLLER','Login');
define('BIND_ACTION','qqReturn');
require dirname(dirname(__FILE__)).'/run.inc.php';
?>