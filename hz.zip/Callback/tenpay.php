<?php
define('BIND_MODULE','Home');
define('BIND_CONTROLLER','Pay');
define('BIND_ACTION','tenpayReturn');
require dirname(dirname(__FILE__)).'/run.inc.php';
?>