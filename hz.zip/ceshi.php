<!doctype html>
<html>
  <body>
    <form action="index.php/Admin/Member/check" method="post">
      <input name="id" value="20,21,22,">
      <input type="submit">
    </form>
  </body>
</html>